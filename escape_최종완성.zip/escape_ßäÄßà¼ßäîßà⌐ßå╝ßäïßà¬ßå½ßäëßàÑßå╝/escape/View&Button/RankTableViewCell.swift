import UIKit

class RankTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLB: UILabel!
    @IBOutlet weak var TimeLB: UILabel!
    
}
